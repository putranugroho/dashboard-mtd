"use client";

import { useMemo, useState } from "react";

import { getBprDetailWithTcodes } from "@/lib/api/bpr";
import { getMasterGLSubtree } from "@/lib/api/mastergl";
import {
  getRekonMappingList,
  saveRekonMapping,
  deactivateRekonMapping,
} from "@/lib/api/rekon-mapping";
import { getSaldoMTDSources } from "@/lib/api/saldo-mtd";
import { PERMISSIONS } from "@/lib/auth/permissions";
import { useSession } from "@/lib/auth/use-session";

import {
  applySBBToRow,
  buildRelasiRows,
  buildRelasiSummary,
  flattenMasterGLToSBBOptions,
} from "./coa-utils";
import RelasiSearchForm from "./RelasiSearchForm";
import RelasiSummaryCards from "./RelasiSummaryCards";
import RelasiTable from "./RelasiTable";
import { RelasiRow, SBBOption } from "./types";

const DEFAULT_USERLOGIN = process.env.NEXT_PUBLIC_DEFAULT_USERLOGIN || "admin";

export default function SetupRelasiRekonsiliasiPage() {
  const [bprId, setBprId] = useState("");
  const [activeBprId, setActiveBprId] = useState("");
  const [bprName, setBprName] = useState("");
  const [rows, setRows] = useState<RelasiRow[]>([]);
  const [options, setOptions] = useState<SBBOption[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  const { can } = useSession();
  const canRelasi = can(PERMISSIONS.SETUP_RELASI_REKONSILIASI_RELASI);
  const canSavePermission = can(PERMISSIONS.SETUP_RELASI_REKONSILIASI_SAVE);
  const canDelete = can(PERMISSIONS.SETUP_RELASI_REKONSILIASI_DELETE);

  const summary = useMemo(() => buildRelasiSummary(rows), [rows]);
  const hasSelectedRows = useMemo(() => rows.some((row) => row.selected_sbb_code), [rows]);

  const refreshRows = async (targetBprId = activeBprId) => {
    const [saldoSources, existingMappings] = await Promise.all([
      getSaldoMTDSources(targetBprId),
      getRekonMappingList(targetBprId),
    ]);

    setRows(buildRelasiRows(saldoSources, existingMappings, options));
  };

  const handleDeleteRelasi = async (row: RelasiRow) => {
    if (!canDelete) return;

    if (!row.id) {
      handleSelectSBB(
        rows.findIndex(
          (item) => item.source_type === row.source_type && item.source_code === row.source_code
        ),
        null
      );
      return;
    }

    const ok = window.confirm(
      `Yakin ingin menghapus relasi ${row.source_type} ${row.source_code}?\n\nRelasi akan dinonaktifkan, bukan dihapus permanen.`
    );
    if (!ok) return;

    try {
      setSaving(true);
      await deactivateRekonMapping(row.id, DEFAULT_USERLOGIN);
      await refreshRows();
      window.alert("Relasi berhasil dihapus.");
    } catch (error) {
      console.error(error);
      window.alert(error instanceof Error ? error.message : "Gagal menghapus relasi");
    } finally {
      setSaving(false);
    }
  };

  const handleSearch = async () => {
    if (!canRelasi) {
      window.alert("Anda tidak memiliki akses relasi rekonsiliasi.");
      return;
    }

    const nextBprId = bprId.trim();
    if (!nextBprId) return window.alert("BPR ID wajib diisi.");

    try {
      setLoading(true);
      const [saldoSources, existingMappings, masterGLTree, bprDetail] = await Promise.all([
        getSaldoMTDSources(nextBprId),
        getRekonMappingList(nextBprId),
        getMasterGLSubtree(),
        getBprDetailWithTcodes(nextBprId),
      ]);

      const sbbOptions = flattenMasterGLToSBBOptions(masterGLTree);
      setActiveBprId(nextBprId);
      setBprName(bprDetail?.profile?.nama_bpr || "");
      setOptions(sbbOptions);
      setRows(buildRelasiRows(saldoSources, existingMappings, sbbOptions));
    } catch (error) {
      console.error(error);
      setRows([]);
      setOptions([]);
      setBprName("");
      window.alert(error instanceof Error ? error.message : "Gagal memuat data setup relasi rekonsiliasi");
    } finally {
      setLoading(false);
    }
  };

  const handleSelectSBB = (index: number, option: SBBOption | null) => {
    if (!canRelasi) return;
    setRows((prev) => prev.map((row, rowIndex) => (rowIndex === index ? applySBBToRow(row, option) : row)));
  };

  const handleSave = async () => {
    if (!canSavePermission) {
      window.alert("Anda tidak memiliki akses menyimpan relasi.");
      return;
    }
    if (!activeBprId) return window.alert("Silakan cari BPR ID terlebih dahulu.");

    const payloadRows = rows
      .filter((row) => row.selected_sbb_code)
      .map((row) => ({
        source_type: row.source_type,
        source_code: row.source_code,
        source_name: row.source_name,
        sbb_code: row.selected_sbb_code,
        sbb_name: row.selected_sbb_name,
        sbb_nobb: row.selected_sbb_nobb,
        sbb_gol_acc: row.selected_sbb_gol_acc,
        sbb_jns_acc: row.selected_sbb_jns_acc,
        sbb_type_posting: row.selected_sbb_type_posting,
        sbb_nonaktif: row.selected_sbb_nonaktif,
        is_active: true,
      }));

    if (payloadRows.length === 0) return window.alert("Pilih minimal 1 relasi SBB sebelum menyimpan.");

    try {
      setSaving(true);
      const res = await saveRekonMapping({ userlogin: DEFAULT_USERLOGIN, bpr_id: activeBprId, data: payloadRows });
      await refreshRows(activeBprId);
      window.alert(res.message || "Relasi rekonsiliasi berhasil disimpan.");
    } catch (error) {
      console.error(error);
      window.alert(error instanceof Error ? error.message : "Gagal menyimpan relasi rekonsiliasi");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <RelasiSearchForm
        bprId={bprId}
        bprName={bprName}
        loading={loading}
        saving={saving}
        rowsCount={rows.length}
        hasSelectedRows={hasSelectedRows}
        canRelasi={canRelasi}
        canSave={canSavePermission}
        onChangeBprId={setBprId}
        onSearch={handleSearch}
        onSave={handleSave}
      />

      {rows.length > 0 ? <RelasiSummaryCards summary={summary} /> : null}

      <RelasiTable
        rows={rows}
        options={options}
        loading={loading || saving}
        onSelectSBB={handleSelectSBB}
        onDeleteRelasi={handleDeleteRelasi}
        canRelasi={canRelasi}
        canDelete={canDelete}
      />
    </div>
  );
}
